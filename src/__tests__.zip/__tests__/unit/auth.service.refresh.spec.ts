/**
 * Tests de refresh (service) con Prisma + crypto mockeados.
 * IMPORTANTE: el mock de prisma va ANTES de importar el service.
 */
jest.mock("../../prisma/client", () => ({
  prisma: {
    session: {
      findUnique: jest.fn(),
      updateMany: jest.fn(),
      update: jest.fn(),
    },
    usuario: { update: jest.fn() },
  },
}));

import { prisma } from "../../prisma/client";
import { authService } from "../../modules/auth/auth.service";
import * as crypto from "../../libs/crypto";
import { UnauthorizedError } from "../../libs/errors";

jest.spyOn(crypto, "hashRefreshToken");

const refreshToken = "RT_VALUE";
const platform = "WEB"; // coincide con tu Platform
const ip = "127.0.0.1";
const userAgent = "jest";

describe("[AuthService] refresh", () => {
  afterEach(() => jest.clearAllMocks());

  test("token no encontrado → UnauthorizedError", async () => {
    (crypto.hashRefreshToken as jest.Mock).mockReturnValue("RT_HASH");
    (prisma.session.findUnique as jest.Mock).mockResolvedValueOnce(null);

    await expect(
      authService.refresh(refreshToken, platform as any, ip, userAgent)
    ).rejects.toBeInstanceOf(UnauthorizedError);
  });

  test("token reuse detectado → UnauthorizedError (según tu servicio)", async () => {
    // Tu servicio cuando no encuentra sesión por el hash, lanza Unauthorized y revoca posibles tokens (updateMany)
    (crypto.hashRefreshToken as jest.Mock).mockReturnValue("RT_HASH");
    (prisma.session.findUnique as jest.Mock).mockResolvedValueOnce(null);
    (prisma.session.updateMany as jest.Mock).mockResolvedValueOnce({ count: 1 });

    await expect(
      authService.refresh(refreshToken, platform as any, ip, userAgent)
    ).rejects.toBeInstanceOf(UnauthorizedError);

    expect(prisma.session.updateMany).toHaveBeenCalled();
  });

  test("expirado → UnauthorizedError", async () => {
    (crypto.hashRefreshToken as jest.Mock).mockReturnValue("RT_HASH");
    (prisma.session.findUnique as jest.Mock).mockResolvedValueOnce({
      id: "s1",
      userId: "u1",
      refreshTokenHash: "RT_HASH",
      platform: "WEB",
      user: { activo: true },
      refreshExpiresAt: new Date(Date.now() - 1000),
      revokedAt: null,
    });

    await expect(
      authService.refresh(refreshToken, platform as any, ip, userAgent)
    ).rejects.toBeInstanceOf(UnauthorizedError);
  });

  test("platform mismatch → UnauthorizedError", async () => {
    (crypto.hashRefreshToken as jest.Mock).mockReturnValue("RT_HASH");
    (prisma.session.findUnique as jest.Mock).mockResolvedValueOnce({
      id: "s1",
      userId: "u1",
      refreshTokenHash: "RT_HASH",
      platform: "MOBILE",
      user: { activo: true },
      refreshExpiresAt: new Date(Date.now() + 3600_000),
      revokedAt: null,
    });

    await expect(
      authService.refresh(refreshToken, platform as any, ip, userAgent)
    ).rejects.toBeInstanceOf(UnauthorizedError);
  });

  test("OK → rota refresh, actualiza sesión y devuelve nuevo access", async () => {
    (crypto.hashRefreshToken as jest.Mock).mockReturnValue("RT_HASH");
    (prisma.session.findUnique as jest.Mock).mockResolvedValueOnce({
      id: "s1",
      userId: "u1",
      refreshTokenHash: "RT_HASH",
      platform: "WEB",
      user: { activo: true },
      refreshExpiresAt: new Date(Date.now() + 3600_000),
      revokedAt: null,
    });
    (prisma.session.updateMany as jest.Mock).mockResolvedValueOnce({ count: 1 });
    (prisma.session.update as jest.Mock).mockResolvedValueOnce({ id: "s1" });

    const result = await authService.refresh(
      refreshToken,
      platform as any,
      ip,
      userAgent
    );

    expect(result.tokens.accessToken).toBeDefined();
    expect(prisma.session.updateMany).toHaveBeenCalledWith(
      expect.objectContaining({
        where: expect.objectContaining({
          id: "s1",
          refreshTokenHash: "RT_HASH",
        }),
      })
    );
    expect(prisma.session.update).toHaveBeenCalled();
  });
});
