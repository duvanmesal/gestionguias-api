import { authService } from "../../modules/auth/auth.service";
import { prisma } from "../../prisma/client";
import { NotFoundError, UnauthorizedError } from "../../libs/errors";

jest.mock("../../prisma/client", () => ({
  prisma: {
    session: {
      findMany: jest.fn(),
      updateMany: jest.fn(),
      findUnique: jest.fn(),
      findFirst: jest.fn(),
      update: jest.fn(),
    },
  },
}));

describe("[AuthService] sessions & revoke", () => {
  afterEach(() => jest.clearAllMocks());

  test("listSessions devuelve activas ordenadas", async () => {
    (prisma.session.findMany as jest.Mock).mockResolvedValueOnce([
      { id: "s2", createdAt: new Date(), platform: "WEB" },
      { id: "s1", createdAt: new Date(Date.now() - 1000), platform: "MOBILE" },
    ]);

    const out = await authService.listSessions("u1");
    expect(out.length).toBe(2);
    expect(prisma.session.findMany).toHaveBeenCalledWith(
      expect.objectContaining({
        where: expect.objectContaining({ userId: "u1", revokedAt: null }),
      })
    );
  });

  test("revokeSession marca revokedAt solo si pertenece al user", async () => {
    (prisma.session.findUnique as jest.Mock).mockResolvedValueOnce({
      id: "s1",
      userId: "u1",
      revokedAt: null,
    });
    (prisma.session.update as jest.Mock).mockResolvedValueOnce({
      id: "s1",
      revokedAt: new Date(),
    });

    await authService.revokeSession("s1", "u1");
    expect(prisma.session.update).toHaveBeenCalled();
  });

  test("revokeSession: sesión no encontrada → NotFoundError", async () => {
    (prisma.session.findFirst as jest.Mock).mockResolvedValueOnce(null);
    await expect(authService.revokeSession("sX", "u1")).rejects.toBeInstanceOf(
      NotFoundError
    );
  });

  test("logoutAll revoca todas", async () => {
    (prisma.session.updateMany as jest.Mock).mockResolvedValueOnce({
      count: 3,
    });
    await authService.logoutAll("u1");
    expect(prisma.session.updateMany).toHaveBeenCalledWith(
      expect.objectContaining({
        where: expect.objectContaining({ userId: "u1", revokedAt: null }),
      })
    );
  });
});
